#!/bin/sh
./tonminer -w $WALLET
