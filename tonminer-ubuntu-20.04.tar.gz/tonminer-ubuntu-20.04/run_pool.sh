#!/bin/sh
./tonminer -w $WALLET -p https://next.ton-pool.com

